import excel2json

excel2json.convert_from_file('.xlsx')
